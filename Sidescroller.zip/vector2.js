
var Vector2 = function(){};


	
this.Vector2.prototype 		
{
	this.x = canvas.width/2;
	this.y = canvas.height/2;
	normalize();
	this.x.v2 += canvas.width/2;
	this.y.v2 += canvas.height/2;
	this.x.v2 -= canvas.width/2;
	this.y.v2 -= canvas.height/2;
	this.x = this x * num;
	this.y = this.y * num;	
}