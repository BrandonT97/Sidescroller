var canvas = document.getElementById("gameCanvas");
var context = canvas.getContext("2d");

var Keyboard = function() {
	var self = this;
	
	window.addEventListener('keydown', function(evt) { self.onKeyDown(evt);}, false);
	window.addEventListener('keyup', function(evt){ self.onKeyUp(evt); }, false);
	
	this.keyListeners = new Array();
	this.keys = new Array();
	
	//a link with these key numbers should be in your notes somewhere
	this.KEY_SPACE = 32;
	this.KEY_LEFT = 37;
	this.KEY_UP = 38;
	this.KEY_DOWN = 39;
	this.KEY_RIGHT = 40;
	
	this.KEY_A = 65;
	this.KEY_D = 68;
	this.KEY_S = 83;
	this.KEY_W = 87;
	this.KEY_SHIFT = 16;
};
Keyboard.prototype.onKeyDown = function(evt)
{
	this.keys[evt.keyCode] = true;
};
Keyboard.prototype.onKeyUp = function(evt)
{
	this.keys[evt.keyCode] = false;
};
Keyboard.prototype.onKeyDown = function(keyCode)
{
return this.keys[keyCode];
};
var Player = function(){
	this.image = document.createElement("img");
	this.x = canvas.width/2;
	this.y = canvas.height/2;
	this.width = 159;
	this.height = 163;
	
	this.image.src = "hero.png";
}
Player.prototype.update = function(deltaTime)
{
	if( typeof(this.rotation) == "undefined" )
		this.rotation = 0;
	
	if (Keyboard.isKeyDown(Keyboard.kEY_SPACE) == true)
	{
		this.rotation -= deltaTime;
	}
	else
	{
		this.rotation += deltaTime;
	}
Player.prototype.draw = function()
{
	context.save()
		context.translate(this.x, this.y);
		context.drawImage(this.image, -this.width/2, -this.height/2);
	context.restore();
}
}
